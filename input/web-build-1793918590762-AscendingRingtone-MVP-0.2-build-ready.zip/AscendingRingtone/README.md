# Ascending Ringtone — MVP 0.1

This project is a proof-of-concept for an Android app that gradually increases the **phone ringtone volume** during an incoming cellular call.

## Current scope

- Incoming cellular calls only.
- Start volume: 5–100% (default 10%).
- Target volume: 5–100% (default 100%).
- Duration: 3–60 seconds (default 10 seconds).
- Linear or smoothstep ramp.
- Saves the user's current ring volume and restores it when the call ends.
- Test button for trying the ramp without making a real call.
- No contacts, call log, SMS, internet, or microphone access.

## Important Android design choice

The app listens for `ACTION_PHONE_STATE_CHANGED`, which Android lists among the implicit broadcasts exempt from the normal manifest-registration restriction. The ramp itself is intentionally short-lived. The implementation uses a normal background service started from the phone-state broadcast rather than declaring a `phoneCall` foreground service; Android 14+ reserves the `phoneCall` foreground-service type for apps with `MANAGE_OWN_CALLS` or the default dialer role.

This is an MVP hypothesis that must be validated on real Android 14/15/16 devices, especially OEM builds such as Xiaomi HyperOS. If a particular OEM blocks the short service, the next iteration will evaluate an alternative architecture rather than adding broad permissions blindly.

## Build

Open the project in Android Studio and build the debug APK. The project targets SDK 35, uses Java/Kotlin 17, and has only the AndroidX Core dependency.

The current development environment used to prepare this archive does not contain the Android SDK/build-tools, so an APK has **not** been claimed as built or tested here.

## First device test

1. Install the debug APK.
2. Grant **Phone** permission.
3. Enable the feature.
4. Set Start = 10%, Target = 100%, Duration = 10 s.
5. Set the phone's normal ringtone volume to a known value, e.g. 70%.
6. Run **Test ringtone**.
7. Then make a real call with the screen on.
8. Repeat with the screen locked/off.
9. Repeat after swiping the app away from Recents.
10. Verify that the original ringtone volume is restored after answer/reject/end.

On Xiaomi/HyperOS, if the app does not survive in the background, test with the app's battery/background/autostart restrictions disabled for this app. That is a device-specific compatibility test, not a requirement we should bake into the product until necessary.

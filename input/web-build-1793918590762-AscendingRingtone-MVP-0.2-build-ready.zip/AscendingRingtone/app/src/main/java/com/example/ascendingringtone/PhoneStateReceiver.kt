package com.example.ascendingringtone

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.media.AudioManager
import android.telephony.TelephonyManager

/** Receives the system phone-state broadcast and controls the short ramp window. */
class PhoneStateReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action != TelephonyManager.ACTION_PHONE_STATE_CHANGED) return

        when (intent.getStringExtra(TelephonyManager.EXTRA_STATE)) {
            TelephonyManager.EXTRA_STATE_RINGING -> {
                if (Settings.enabled(context)) onRinging(context)
            }
            TelephonyManager.EXTRA_STATE_OFFHOOK,
            TelephonyManager.EXTRA_STATE_IDLE -> onCallEnded(context)
        }
    }

    private fun onRinging(context: Context) {
        // Some devices may emit more than one RINGING broadcast for the same call.
        // Only the first one should capture the user's original volume and start the ramp.
        if (Settings.isActive(context)) return

        val audio = context.getSystemService(AudioManager::class.java)
        if (audio.isVolumeFixed) return

        val original = audio.getStreamVolume(AudioManager.STREAM_RING)
        val max = audio.getStreamMaxVolume(AudioManager.STREAM_RING)
        if (max <= 0) return

        val start = Settings.start(context).coerceIn(0, 100)
        val target = Settings.target(context).coerceIn(start, 100)

        Settings.setOriginal(context, original)
        Settings.setActive(context, true)

        // Change the ring stream before starting the ramp service. This avoids a
        // possible first loud step caused by the ringtone already being active.
        audio.setStreamVolume(
            AudioManager.STREAM_RING,
            VolumeRamp.percentToIndex(start, max),
            0
        )

        val serviceIntent = Intent(context, RampService::class.java).apply {
            action = RampService.ACTION_START
            putExtra(RampService.EXTRA_TARGET, target)
        }

        try {
            // ACTION_PHONE_STATE_CHANGED is an exempt broadcast. Android's background
            // execution rules temporarily allow work triggered by a system broadcast;
            // the ramp is deliberately short-lived (max 60 s).
            context.startService(serviceIntent)
        } catch (_: IllegalStateException) {
            // The initial volume change has already happened. If the service cannot be
            // started on a particular OEM build, the call still rings at the start level.
        } catch (_: SecurityException) {
            // Same graceful fallback for OEM-specific restrictions.
        }
    }

    private fun onCallEnded(context: Context) {
        if (!Settings.isActive(context)) return

        try {
            context.stopService(Intent(context, RampService::class.java))
        } catch (_: Exception) {
            // Nothing else is required; restoration below is independent of the service.
        }

        val original = Settings.original(context)
        val audio = context.getSystemService(AudioManager::class.java)
        if (original >= 0 && !audio.isVolumeFixed) {
            audio.setStreamVolume(AudioManager.STREAM_RING, original, 0)
        }
        Settings.clearActive(context)
    }
}

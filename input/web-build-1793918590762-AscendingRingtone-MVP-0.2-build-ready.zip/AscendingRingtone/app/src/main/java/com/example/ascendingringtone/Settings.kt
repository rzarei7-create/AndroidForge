package com.example.ascendingringtone

import android.content.Context

object Settings {
    private const val PREFS = "settings"
    private const val ENABLED = "enabled"
    private const val START = "start"
    private const val TARGET = "target"
    private const val DURATION = "duration"
    private const val SMOOTH = "smooth"
    private const val ACTIVE = "active"
    private const val ORIGINAL = "original"

    fun prefs(context: Context) = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    fun enabled(context: Context) = prefs(context).getBoolean(ENABLED, true)
    fun setEnabled(context: Context, value: Boolean) = prefs(context).edit().putBoolean(ENABLED, value).apply()

    fun start(context: Context) = prefs(context).getInt(START, 10)
    fun setStart(context: Context, value: Int) = prefs(context).edit().putInt(START, value).apply()

    fun target(context: Context) = prefs(context).getInt(TARGET, 100)
    fun setTarget(context: Context, value: Int) = prefs(context).edit().putInt(TARGET, value).apply()

    fun duration(context: Context) = prefs(context).getInt(DURATION, 10)
    fun setDuration(context: Context, value: Int) = prefs(context).edit().putInt(DURATION, value).apply()

    fun smooth(context: Context) = prefs(context).getBoolean(SMOOTH, true)
    fun setSmooth(context: Context, value: Boolean) = prefs(context).edit().putBoolean(SMOOTH, value).apply()

    fun isActive(context: Context) = prefs(context).getBoolean(ACTIVE, false)
    fun setActive(context: Context, value: Boolean) = prefs(context).edit().putBoolean(ACTIVE, value).apply()

    fun original(context: Context) = prefs(context).getInt(ORIGINAL, -1)
    fun setOriginal(context: Context, value: Int) = prefs(context).edit().putInt(ORIGINAL, value).apply()

    fun clearActive(context: Context) = prefs(context).edit().remove(ACTIVE).remove(ORIGINAL).apply()
}

package com.example.ascendingringtone

import kotlin.math.roundToInt

/** Converts user-facing percentages into Android's device-specific ring-volume index. */
object VolumeRamp {
    fun percentToIndex(percent: Int, maxIndex: Int): Int {
        if (maxIndex <= 0) return 0
        return ((percent.coerceIn(0, 100) / 100.0) * maxIndex)
            .roundToInt()
            .coerceIn(0, maxIndex)
    }

    fun indexForElapsed(
        elapsedMs: Long,
        durationMs: Long,
        startPercent: Int,
        targetPercent: Int,
        maxIndex: Int,
        smooth: Boolean
    ): Int {
        if (durationMs <= 0) return percentToIndex(targetPercent, maxIndex)

        var t = (elapsedMs.toDouble() / durationMs.toDouble()).coerceIn(0.0, 1.0)
        if (smooth) {
            // Smoothstep: zero slope at both ends, avoiding an abrupt first/last jump.
            t = t * t * (3.0 - 2.0 * t)
        }

        val p = startPercent.coerceIn(0, 100) +
            (targetPercent.coerceIn(0, 100) - startPercent.coerceIn(0, 100)) * t
        return percentToIndex(p.roundToInt(), maxIndex)
    }
}

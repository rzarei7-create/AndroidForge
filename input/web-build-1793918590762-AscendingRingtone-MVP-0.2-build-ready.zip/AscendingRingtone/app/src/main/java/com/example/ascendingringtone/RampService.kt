package com.example.ascendingringtone

import android.app.Service
import android.content.Intent
import android.media.AudioManager
import android.os.Handler
import android.os.IBinder
import android.os.Looper

/** Short-lived service used only while a call is ringing. */
class RampService : Service() {
    companion object {
        const val ACTION_START = "com.example.ascendingringtone.START"
        const val EXTRA_TARGET = "target"
    }

    private val handler = Handler(Looper.getMainLooper())
    private var startedAt = 0L
    private var targetPercent = 100
    private var durationMs = 10_000L
    private var smooth = true
    private val audio by lazy { getSystemService(AudioManager::class.java) }

    private val tick = object : Runnable {
        override fun run() {
            if (!Settings.isActive(this@RampService) || audio.isVolumeFixed) {
                stopSelf()
                return
            }

            val elapsed = System.currentTimeMillis() - startedAt
            val index = VolumeRamp.indexForElapsed(
                elapsed,
                durationMs,
                Settings.start(this@RampService),
                targetPercent,
                audio.getStreamMaxVolume(AudioManager.STREAM_RING),
                smooth
            )
            audio.setStreamVolume(AudioManager.STREAM_RING, index, 0)

            if (elapsed < durationMs) {
                handler.postDelayed(this, 100L)
            } else {
                stopSelf()
            }
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action != ACTION_START || !Settings.isActive(this)) {
            stopSelfResult(startId)
            return START_NOT_STICKY
        }

        targetPercent = intent.getIntExtra(
            EXTRA_TARGET,
            Settings.target(this)
        ).coerceIn(Settings.start(this), 100)
        durationMs = Settings.duration(this).coerceIn(1, 60) * 1000L
        smooth = Settings.smooth(this)
        startedAt = System.currentTimeMillis()

        handler.removeCallbacks(tick)
        handler.post(tick)
        return START_NOT_STICKY
    }

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}

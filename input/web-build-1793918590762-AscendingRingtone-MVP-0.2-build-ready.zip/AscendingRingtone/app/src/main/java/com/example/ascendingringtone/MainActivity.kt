package com.example.ascendingringtone

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.media.AudioManager
import android.media.RingtoneManager
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.telephony.TelephonyManager
import android.view.View
import android.widget.Button
import android.widget.CheckBox
import android.widget.SeekBar
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import kotlin.math.roundToInt

class MainActivity : Activity() {
    private lateinit var enabled: Switch
    private lateinit var startSeek: SeekBar
    private lateinit var targetSeek: SeekBar
    private lateinit var durationSeek: SeekBar
    private lateinit var smooth: CheckBox
    private lateinit var startLabel: TextView
    private lateinit var targetLabel: TextView
    private lateinit var durationLabel: TextView
    private lateinit var status: TextView

    private val handler = Handler(Looper.getMainLooper())
    private var testRingtone: android.media.Ringtone? = null
    private var testOriginal = -1
    private var testStarted = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        enabled = findViewById(R.id.enabledSwitch)
        startSeek = findViewById(R.id.startSeek)
        targetSeek = findViewById(R.id.targetSeek)
        durationSeek = findViewById(R.id.durationSeek)
        smooth = findViewById(R.id.smoothCheck)
        startLabel = findViewById(R.id.startLabel)
        targetLabel = findViewById(R.id.targetLabel)
        durationLabel = findViewById(R.id.durationLabel)
        status = findViewById(R.id.statusText)

        loadSettings()
        wireControls()
        findViewById<Button>(R.id.testButton).setOnClickListener { testRamp() }
        findViewById<Button>(R.id.phonePermissionButton).setOnClickListener { requestPhonePermission() }
        updateStatus()
    }

    private fun loadSettings() {
        enabled.isChecked = com.example.ascendingringtone.Settings.enabled(this)
        startSeek.progress = com.example.ascendingringtone.Settings.start(this) - 5
        targetSeek.progress = com.example.ascendingringtone.Settings.target(this)
        durationSeek.progress = com.example.ascendingringtone.Settings.duration(this) - 3
        smooth.isChecked = com.example.ascendingringtone.Settings.smooth(this)
        updateLabels()
    }

    private fun wireControls() {
        enabled.setOnCheckedChangeListener { _, value ->
            com.example.ascendingringtone.Settings.setEnabled(this, value)
            updateStatus()
        }
        startSeek.setOnSeekBarChangeListener(simpleListener { value ->
            val start = (value + 5).coerceAtMost(com.example.ascendingringtone.Settings.target(this))
            com.example.ascendingringtone.Settings.setStart(this, start)
            startSeek.progress = start - 5
            updateLabels()
        })
        targetSeek.setOnSeekBarChangeListener(simpleListener { value ->
            val target = value.coerceIn(5, 100)
            val start = com.example.ascendingringtone.Settings.start(this)
            com.example.ascendingringtone.Settings.setTarget(this, target.coerceAtLeast(start))
            targetSeek.progress = com.example.ascendingringtone.Settings.target(this)
            updateLabels()
        })
        durationSeek.setOnSeekBarChangeListener(simpleListener { value ->
            val duration = value + 3
            com.example.ascendingringtone.Settings.setDuration(this, duration)
            updateLabels()
        })
        smooth.setOnCheckedChangeListener { _, value -> com.example.ascendingringtone.Settings.setSmooth(this, value) }
    }

    private fun simpleListener(onProgress: (Int) -> Unit) = object : SeekBar.OnSeekBarChangeListener {
        override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) { if (fromUser) onProgress(progress) }
        override fun onStartTrackingTouch(seekBar: SeekBar?) = Unit
        override fun onStopTrackingTouch(seekBar: SeekBar?) = Unit
    }

    private fun updateLabels() {
        startLabel.text = "Start volume: ${com.example.ascendingringtone.Settings.start(this)}%"
        targetLabel.text = "Target volume: ${com.example.ascendingringtone.Settings.target(this)}%"
        durationLabel.text = "Increase duration: ${com.example.ascendingringtone.Settings.duration(this)} seconds"
    }

    private fun updateStatus() {
        val granted = ContextCompat.checkSelfPermission(this, Manifest.permission.READ_PHONE_STATE) == PackageManager.PERMISSION_GRANTED
        status.text = "Status: ${if (enabled.isChecked) "ON" else "OFF"} • Phone access: ${if (granted) "allowed" else "required"}"
    }

    private fun requestPhonePermission() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.READ_PHONE_STATE) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.READ_PHONE_STATE), 100)
        } else {
            Toast.makeText(this, "Phone-state access is already allowed.", Toast.LENGTH_SHORT).show()
        }
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        updateStatus()
    }

    private fun testRamp() {
        if (testStarted) return
        val audio = getSystemService(AudioManager::class.java)
        val max = audio.getStreamMaxVolume(AudioManager.STREAM_RING)
        testOriginal = audio.getStreamVolume(AudioManager.STREAM_RING)
        val start = com.example.ascendingringtone.Settings.start(this)
        val target = com.example.ascendingringtone.Settings.target(this).coerceAtLeast(start)
        val duration = com.example.ascendingringtone.Settings.duration(this) * 1000L
        val smoothValue = com.example.ascendingringtone.Settings.smooth(this)
        val uri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_RINGTONE)
        testRingtone = RingtoneManager.getRingtone(this, uri)
        testStarted = true

        // Set the initial volume before playback so the test does not begin with
        // the user's normal (possibly loud) ringtone volume.
        audio.setStreamVolume(
            AudioManager.STREAM_RING,
            VolumeRamp.percentToIndex(start, max),
            0
        )
        testRingtone?.play()
        val began = System.currentTimeMillis()

        val runner = object : Runnable {
            override fun run() {
                if (!testStarted) return
                val elapsed = System.currentTimeMillis() - began
                val idx = VolumeRamp.indexForElapsed(elapsed, duration, start, target, max, smoothValue)
                audio.setStreamVolume(AudioManager.STREAM_RING, idx, 0)
                if (elapsed < duration) handler.postDelayed(this, 100L) else finishTest()
            }
        }
        handler.post(runner)
    }

    private fun finishTest() {
        if (!testStarted) return
        testStarted = false
        testRingtone?.stop()
        testRingtone = null
        if (testOriginal >= 0) getSystemService(AudioManager::class.java).setStreamVolume(AudioManager.STREAM_RING, testOriginal, 0)
        testOriginal = -1
    }

    override fun onDestroy() {
        finishTest()
        super.onDestroy()
    }
}
